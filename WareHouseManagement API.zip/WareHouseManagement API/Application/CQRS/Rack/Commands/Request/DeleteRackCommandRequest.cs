﻿namespace Application.CQRS.Racks.Commands.Request;

public class DeleteRackCommandRequest
{
    public Guid Id { get; set; }
}