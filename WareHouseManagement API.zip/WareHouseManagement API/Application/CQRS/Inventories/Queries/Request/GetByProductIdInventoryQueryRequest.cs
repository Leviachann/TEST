﻿namespace Application.CQRS.Inventories.Query.Request;
public class GetByProductInventoryQueryRequest 
{ 
    public Guid ProductId { get; set; }
}