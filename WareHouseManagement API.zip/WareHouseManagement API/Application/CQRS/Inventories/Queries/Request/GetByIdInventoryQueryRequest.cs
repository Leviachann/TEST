﻿namespace Application.CQRS.Inventories.Queries.Request;
public class GetInventoryByIdQueryRequest
{
    public Guid Id { get; set; }
}