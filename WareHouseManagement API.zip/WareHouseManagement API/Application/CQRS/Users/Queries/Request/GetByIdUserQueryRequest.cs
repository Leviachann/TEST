﻿namespace Application.CQRS.Users.Queries.Request;

public class GetUserByIdQueryRequest
{
    public Guid Id { get; set; }
}
