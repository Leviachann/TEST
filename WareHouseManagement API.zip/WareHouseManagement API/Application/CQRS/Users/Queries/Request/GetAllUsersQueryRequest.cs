﻿namespace Application.CQRS.Users.Queries.Request;

public class GetAllUsersQueryRequest 
{
}
