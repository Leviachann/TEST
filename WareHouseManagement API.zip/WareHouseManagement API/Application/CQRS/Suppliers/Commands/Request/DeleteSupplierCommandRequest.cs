﻿namespace Application.CQRS.Suppliers.Commands.Request;

public class DeleteSupplierCommandRequest
{
    public Guid Id { get; set; }
}
