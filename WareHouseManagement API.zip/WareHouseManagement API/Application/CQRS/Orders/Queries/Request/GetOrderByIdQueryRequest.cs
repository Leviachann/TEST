﻿namespace Application.CQRS.Orders.Queries.Request;

public class GetOrderByIdQueryRequest
{
    public Guid Id { get; set; }
}
