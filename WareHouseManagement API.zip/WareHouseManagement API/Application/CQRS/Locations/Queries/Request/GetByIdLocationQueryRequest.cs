﻿namespace Application.CQRS.Locations.Queries.Request;

public class GetByIdLocationQueryRequest
{
    public Guid Id { get; set; }
}
