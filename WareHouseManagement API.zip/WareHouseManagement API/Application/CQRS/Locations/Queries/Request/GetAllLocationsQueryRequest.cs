﻿namespace Application.CQRS.Locations.Queries.Request;

public class GetAllLocationsQueryRequest{
}
