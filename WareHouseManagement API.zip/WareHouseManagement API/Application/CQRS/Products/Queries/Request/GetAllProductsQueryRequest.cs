﻿namespace Application.CQRS.Products.Queries.Request;

public class GetAllProductsQueryRequest
{
}
