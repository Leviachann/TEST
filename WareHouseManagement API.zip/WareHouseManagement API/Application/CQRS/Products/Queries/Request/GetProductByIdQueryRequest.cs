﻿namespace Application.CQRS.Products.Queries.Request;

public class GetProductByIdQueryRequest
{
    public Guid Id { get; set; }
}
