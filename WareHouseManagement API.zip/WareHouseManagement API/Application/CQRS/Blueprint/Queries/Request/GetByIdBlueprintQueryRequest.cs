﻿namespace Application.CQRS.Blueprints.Queries.Request;

public class GetByIdBlueprintQueryRequest
{
    public Guid Id { get; set; }
}