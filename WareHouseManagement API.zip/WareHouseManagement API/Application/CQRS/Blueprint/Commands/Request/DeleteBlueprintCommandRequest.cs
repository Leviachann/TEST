﻿namespace Application.CQRS.Blueprints.Commands.Request;

public class DeleteBlueprintCommandRequest
{
    public Guid Id { get; set; }
}