﻿namespace Application.CQRS.Auth.Requests;

public class RefreshTokenRequest
{
    public string RefreshToken { get; set; }
}