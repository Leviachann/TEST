﻿namespace Application.CQRS.Categories.Queries.Request;
public class GetCategoryByIdQueryRequest
{
    public Guid Id { get; set; }
}