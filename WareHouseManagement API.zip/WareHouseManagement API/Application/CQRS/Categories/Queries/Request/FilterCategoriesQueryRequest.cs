﻿namespace Application.CQRS.Categories.Queries.Request;
public class FilterCategoriesQueryRequest
{
    public string Name { get; set; }
}
