﻿namespace Application.CQRS.Categories.Commands.Request;

public class AddCategoryCommandRequest
{
    public string Name { get; set; }
}
