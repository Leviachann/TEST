﻿namespace Domain.Enums;

public enum ArrivalStatus
{
    Pending,
    Ordered,
    Shipping,
    Arrived
}
