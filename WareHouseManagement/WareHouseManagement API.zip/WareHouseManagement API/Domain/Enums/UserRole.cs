﻿namespace Domain.Enums;

public enum UserRole
{
    Admin,
    Moderator,
    WareHouseMan
}
