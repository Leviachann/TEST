﻿namespace Application.CQRS.Inventories.Commands.Request;

public class DeleteInventoriesCommandRequest
{
    public Guid Id { get; set; }
}