﻿namespace Application.CQRS.Inventories.Query.Request;
public class GetAllInventoriesQueryRequest{}