﻿namespace Application.CQRS.Categories.Queries.Request;

public class GetAllCategoriesQueryRequest{ }