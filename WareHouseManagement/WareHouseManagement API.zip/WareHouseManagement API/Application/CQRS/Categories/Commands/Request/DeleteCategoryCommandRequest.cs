﻿namespace Application.CQRS.Categories.Commands.Request;

public class DeleteCategoryCommandRequest
{
    public Guid Id { get; set; }
}
