﻿namespace Application.CQRS.Blueprints.Queries.Request;

public class GetAllBlueprintsQueryRequest
{
}