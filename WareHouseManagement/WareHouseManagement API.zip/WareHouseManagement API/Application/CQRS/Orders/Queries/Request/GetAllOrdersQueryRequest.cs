﻿namespace Application.CQRS.Orders.Queries.Request;

public class GetAllOrdersQueryRequest
{
}
