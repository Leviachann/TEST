﻿namespace Application.CQRS.Racks.Queries.Request;

public class GetRackByIdQueryRequest
{
    public Guid Id { get; set; }
}