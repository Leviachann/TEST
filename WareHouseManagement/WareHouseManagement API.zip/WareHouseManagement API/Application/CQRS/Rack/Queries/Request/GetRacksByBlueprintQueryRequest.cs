﻿namespace Application.CQRS.Racks.Queries.Request;

public class GetRacksByBlueprintQueryRequest
{
    public Guid BlueprintId { get; set; }
}