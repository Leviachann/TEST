﻿namespace Application.CQRS.OrderLines.Queries.Request;

public class GetAllOrderLinesQueryRequest
{
}
