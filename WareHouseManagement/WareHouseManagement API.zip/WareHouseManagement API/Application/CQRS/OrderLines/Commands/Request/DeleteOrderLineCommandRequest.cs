﻿namespace Application.CQRS.OrderLines.Commands.Request;

public class DeleteOrderLineCommandRequest 
{
    public Guid Id { get; set; }
}
