﻿namespace Application.CQRS.Products.Commands.Request;

public class DeleteProductCommandRequest
{
    public Guid Id { get; set; }
}
