﻿namespace Application.CQRS.Locations.Commands.Request;

public class DeleteLocationCommandRequest
{
    public Guid Id { get; set; }
}
