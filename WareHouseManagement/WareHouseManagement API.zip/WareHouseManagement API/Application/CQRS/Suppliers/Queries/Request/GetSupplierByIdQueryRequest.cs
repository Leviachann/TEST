﻿namespace Application.CQRS.Suppliers.Queries.Request;

public class GetSupplierByIdQueryRequest
{
    public Guid Id { get; set; }
}
