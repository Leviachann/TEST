﻿namespace Application.CQRS.Suppliers.Queries.Request;

public class GetAllSuppliersQueryRequest
{
}
